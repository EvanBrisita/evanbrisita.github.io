Start: Double click the application
End: Alt f4
Requires: Keyboard
