Start: Double click the application
End: Press ESC on the keyboard
Requires: 4 Controllers
